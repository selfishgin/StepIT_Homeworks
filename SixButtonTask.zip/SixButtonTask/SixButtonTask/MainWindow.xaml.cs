﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace SixButtonTask
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Random color = new Random();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            button.Background = new SolidColorBrush(Color.FromRgb((byte)color.Next(1, 255), (byte)color.Next(1, 255), (byte)color.Next(1, 255)));
            
            MessageBox.Show($"The color code of the {button.Content}'s button is {button.Background}.");
        }

        private void Button_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            Button? button = sender as Button;
            button.Visibility = Visibility.Collapsed;
            this.Title = "Deleted button: " + button.Content.ToString();
        }


    }


}