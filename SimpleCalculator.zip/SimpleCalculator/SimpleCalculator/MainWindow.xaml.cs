﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SimpleCalculator
{
    public partial class MainWindow : Window
    {
        private double firstNumber = 0;
        private double secondNumber = 0;
        private string operation = "";

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Number_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string digit = button.Content.ToString();
            if (operation == "")
            {
                firstNumber = firstNumber * 10 + Convert.ToDouble(digit);
                resultLabel.Content = firstNumber.ToString();
            }
            else
            {
                secondNumber = secondNumber * 10 + Convert.ToDouble(digit);
                resultLabel.Content = secondNumber.ToString();
            }
        }

        private void Operation_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            operation = button.Content.ToString();
        }

        private void Equals_Click(object sender, RoutedEventArgs e)
        {
            double result = 0;
            switch (operation)
            {
                case "+":
                    result = firstNumber + secondNumber;
                    break;
                case "-":
                    result = firstNumber - secondNumber;
                    break;
                case "*":
                    result = firstNumber * secondNumber;
                    break;
                case "/":
                    if (secondNumber != 0)
                        result = firstNumber / secondNumber;
                    else
                        resultLabel.Content = "Error";
                    break;
            }
            resultLabel.Content = result.ToString();
            firstNumber = result;
            secondNumber = 0;
            operation = "";
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            firstNumber = 0;
            secondNumber = 0;
            operation = "";
            resultLabel.Content = "0";
        }



    }
}
