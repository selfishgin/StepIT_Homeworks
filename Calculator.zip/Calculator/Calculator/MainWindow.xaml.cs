﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Calculator
{
    public partial class MainWindow : Window
    {
        private string currentInput = string.Empty;
        private double result = 0;
        private string lastOperator = string.Empty;
        private bool isNewInput = true;

        public MainWindow()
        {
            InitializeComponent();
            SetupButtons();
        }

        private void SetupButtons()
        {
            foreach (var button in Grid.Children)
            {
                if (button is Button)
                {
                    ((Button)button).Click += Button_Click;
                }
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button clickedButton)
            {
                string content = clickedButton.Content.ToString();

                switch (content)
                {
                    case "%":
                        ApplyPercentage();
                        break;
                    case "√":
                        ApplySquareRoot();
                        break;
                    case "x²":
                        ApplySquare();
                        break;
                    case "1/x":
                        ApplyReciprocal();
                        break;
                    case "CE":
                        ClearEntry();
                        break;
                    case "C":
                        ClearAll();
                        break;
                    case "⌫":
                        Backspace();
                        break;
                    case "+":
                    case "-":
                    case "×":
                    case "÷":
                        HandleOperator(content);
                        break;
                    case "=":
                        CalculateResult();
                        break;
                    case ",":
                        AddDecimalPoint();
                        break;
                    default:
                        AddToInput(content);
                        break;
                }
            }
        }

        private void AddToInput(string input)
        {
            if (isNewInput)
            {
                TextDisplay.Text = input;
                isNewInput = false;
            }
            else
            {
                TextDisplay.Text += input;
            }
        }

        private void ClearEntry()
        {
            TextDisplay.Text = "0";
            isNewInput = true;
        }

        private void ClearAll()
        {
            currentInput = string.Empty;
            result = 0;
            lastOperator = string.Empty;
            TextDisplay.Text = "0";
            isNewInput = true;
        }

        private void Backspace()
        {
            if (TextDisplay.Text.Length > 1)
            {
                TextDisplay.Text = TextDisplay.Text.Substring(0, TextDisplay.Text.Length - 1);
            }
            else
            {
                TextDisplay.Text = "0";
                isNewInput = true;
            }
        }

        private void HandleOperator(string operatorSymbol)
        {
            if (!string.IsNullOrEmpty(lastOperator))
            {
                CalculateResult();
            }

            lastOperator = operatorSymbol;

            if (!double.TryParse(TextDisplay.Text, out result))
            {
                result = 0;
            }

            isNewInput = true;
        }


        private void CalculateResult()
        {
            if (!double.TryParse(TextDisplay.Text, out double input))
            {
                ShowErrorMessage("Invalid input.");
                return;
            }

            switch (lastOperator)
            {
                case "+":
                    result += input;
                    break;
                case "-":
                    result -= input;
                    break;
                case "×":
                    result *= input;
                    break;
                case "÷":
                    if (input != 0)
                    {
                        result /= input;
                    }
                    else
                    {
                        ShowErrorMessage("Cannot divide by zero.");
                        return;
                    }
                    break;
            }
            TextDisplay.Text = result.ToString();
            isNewInput = true;
        }

        private void AddDecimalPoint()
        {
            if (!TextDisplay.Text.Contains("."))
            {
                TextDisplay.Text += ".";
            }
        }

        private void ApplyPercentage()
        {
            if (double.TryParse(TextDisplay.Text, out double input))
            {
                input /= 100;
                TextDisplay.Text = input.ToString();
                isNewInput = true;
            }
            else
            {
                ShowErrorMessage("Invalid input.");
            }
        }

        private void ApplySquareRoot()
        {
            if (double.TryParse(TextDisplay.Text, out double input))
            {
                if (input >= 0)
                {
                    input = Math.Sqrt(input);
                    TextDisplay.Text = input.ToString();
                    isNewInput = true;
                }
                else
                {
                    ShowErrorMessage("Invalid input for square root.");
                }
            }
            else
            {
                ShowErrorMessage("Invalid input.");
            }
        }

        private void ApplySquare()
        {
            if (double.TryParse(TextDisplay.Text, out double input))
            {
                input *= input;
                TextDisplay.Text = input.ToString();
                isNewInput = true;
            }
            else
            {
                ShowErrorMessage("Invalid input.");
            }
        }

        private void ApplyReciprocal()
        {
            if (double.TryParse(TextDisplay.Text, out double input))
            {
                if (input != 0)
                {
                    input = 1 / input;
                    TextDisplay.Text = input.ToString();
                    isNewInput = true;
                }
                else
                {
                    ShowErrorMessage("Cannot take reciprocal of zero.");
                }
            }
            else
            {
                ShowErrorMessage("Invalid input.");
            }
        }

        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
