﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using Microsoft.Win32;

namespace RichTextBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string currentFilePath = ""; 
        private bool autoSaveEnabled = false; 

        public MainWindow()
        {
            InitializeComponent();
            TextPath.Text = "File Name...";
            TextPath.Foreground = Brushes.Gray;
            TextPath.GotFocus += TextPath_GotFocus;
            TextPath.LostFocus += TextPath_LostFocus;
            richTextBox.TextChanged += richTextBox_TextChanged;
        }

        private void TextPath_GotFocus(object sender, RoutedEventArgs e)
        {
            if (TextPath.Text == "File Name...")
            {
                TextPath.Text = "";
                TextPath.Foreground = Brushes.Black;
            }
        }

        private void TextPath_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TextPath.Text))
            {
                TextPath.Text = "File Name...";
                TextPath.Foreground = Brushes.Gray;
            }
        }

        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            richTextBox.Cut();
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            richTextBox.Copy();
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            richTextBox.Paste();
        }

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            richTextBox.SelectAll();
        }

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    string fileName = openFileDialog.FileName;
                    string fileContent = File.ReadAllText(fileName);
                    richTextBox.Document.Blocks.Clear(); 
                    richTextBox.AppendText(fileContent); 
                    currentFilePath = fileName; 
                    TextPath.Text = fileName; 
                    MessageBox.Show("File loaded successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void SaveFile_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(currentFilePath))
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                if (saveFileDialog.ShowDialog() == true)
                {
                    currentFilePath = saveFileDialog.FileName; 
                }
                else
                {
                    return; 
                }
            }

            try
            {
                File.WriteAllText(currentFilePath, new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd).Text);
                MessageBox.Show("File saved successfully.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error occurred while saving the file: {ex.Message}");
            }
        }

        private void richTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (autoSaveEnabled && !string.IsNullOrEmpty(currentFilePath))
            {
                try
                {
                    File.WriteAllText(currentFilePath, new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd).Text);
                    AutoSave.IsChecked = true; // ?
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error occurred while auto-saving the file: {ex.Message}");
                }
            }
        }

        private void AutoSave_Checked(object sender, RoutedEventArgs e)
        {
            autoSaveEnabled = (AutoSave.IsChecked == true); // ?
        }

        private void TextPath_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
