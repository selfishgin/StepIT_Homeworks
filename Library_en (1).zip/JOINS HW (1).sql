﻿/*Database "Library"   
 
1. Display books with the minimum number 
of pages issued by a particular publishing house.
1. Hər Publisherin ən az səhifəli 
kitabını ekrana çıxarın 

2. Display the names of publishers who have issued books with an average number of pages larger than 100.	
2. Publisherin ümumi çap etdiyi kitabların orta səhifəsi 100dən yuxarıdırsa, o Publisherləri ekrana çıxarın.

3. Output the total amount of pages of all the books in the library issued by the publishing houses BHV and BINOM.
3. BHV və BİNOM Publisherlərinin kitabların bütün cəmi səhifəsini ekrana çıxarın

4. Select the names of all students who took books between January 1, 2001 and the current date.
Yanvarın 1-i 2001ci il və bu gün arasında kitabxanadan kitab götürən bütün tələbələrin adlarını ekrana çıxarın

5. Find all students who are currently working with the book "Windows 2000 Registry" by Olga Kokoreva.
5. Olga Kokorevanın  "Windows 2000 Registry" kitabı üzərində işləyən tələbələri tapın

6. Display information about authors whose average volume of books (in pages) is more than 600 pages.
6. Yazdığı bütün kitabları nəzərə aldıqda, orta səhifə sayı 600dən çox olan Yazıçılar haqqında məlumat çıxarın.

7. Display information about publishers, whose total number of pages of books published by them is more than 700.
7. Çap etdiyi bütün kitabların cəmi səhifə sayı 700dən çox olan Publisherlər haqqında ekrana məlumat çıxarın
*/


/*

-- 1.
SELECT
    p.Name AS PressName,
    b.Name AS BookName,
    b.Pages,
    b.YearPress
FROM
    Books b
JOIN
    Press p ON b.Id_Press = p.Id
WHERE
    b.Pages = (
        SELECT MIN(Pages)
        FROM Books
        WHERE Id_Press = b.Id_Press
    )
ORDER BY
    p.Name, b.Pages;


-- 2.
SELECT
    p.Name AS PressName
FROM
    Books b
JOIN
    Press p ON b.Id_Press = p.Id
GROUP BY
    p.Name
HAVING
    AVG(b.Pages) > 100;


-- 3.
SELECT
    SUM(b.Pages) AS TotalPages
FROM
    Books b
JOIN
    Press p ON b.Id_Press = p.Id
WHERE
    p.Name IN ('BHV', 'BINOM');


-- 4.
SELECT DISTINCT
    s.FirstName AS StudentsFirstName,
	s.LastName AS StudentsLastName
FROM
    Students s
JOIN
    S_Cards c ON s.Id = c.Id_Student
WHERE
    c.DateOut BETWEEN '2001-01-01' AND CAST(GETDATE() AS DATE);


-- 5.
SELECT DISTINCT
    s.FirstName AS StudentsFirstName,
	s.LastName AS StudentsLastName,
	a.FirstName AS AuthorFirstName,
	a.FirstName AS AuthorLastName
FROM
    Students s,
	Authors a
JOIN
    S_Cards c ON a.Id = c.Id_Student
JOIN
    Books b ON c.Id_Book = b.Id
WHERE
    b.Name = 'Windows 2000 Registry'
    AND a.FirstName = 'Olga Kokoreva'
    AND c.DateOut IS NULL;


-- 6.
SELECT
    AVG(b.Pages) AS Average_Pages
FROM
    Books b
GROUP BY
    b.Id_Author
HAVING
    AVG(b.Pages) > 600;


-- 7.
SELECT
    --p.Name AS PressName,
    SUM(b.Pages) AS Total_Pages
FROM
    Press p
JOIN
    Books b ON p.Id = b.Id_Press
GROUP BY
    p.Name
HAVING
    SUM(b.Pages) > 700;



*/