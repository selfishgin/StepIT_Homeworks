﻿using System;
using System.IO;
using System.Windows;

namespace YeniAnket
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            SaveFileButton.Click += SaveFileButton_Click;
            LoadFileButton.Click += LoadFileButton_Click;
        }

        private void SaveFileButton_Click(object sender, RoutedEventArgs e)
        {
            string fileName = NameText.Text + ".txt";


            using (StreamWriter writer = new StreamWriter(fileName))
            {
                writer.WriteLine($"Name: {NameText.Text}");
                writer.WriteLine($"Surname: {SurnameText.Text}");
                writer.WriteLine($"Paternal: {PaternalText.Text}");
                writer.WriteLine($"Country: {CountryText.Text}");
                writer.WriteLine($"City: {CityText.Text}");
                writer.WriteLine($"Phone: {PhoneText.Text}");
                writer.WriteLine($"Birth Date: {BirthDatePicker.SelectedDate}");
                writer.WriteLine($"Gender: {(Male.IsChecked == true ? "Male" : "Female")}");
            }
            MessageBox.Show("File saved successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void LoadFileButton_Click(object sender, RoutedEventArgs e)
        {
            string fileName = LoadFile.Text + ".txt";
            if (File.Exists(fileName))
            {
                string[] lines = File.ReadAllLines(fileName);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(new char[] { ':' }, 2);
                    if (parts.Length == 2)
                    {
                        string key = parts[0].Trim();
                        string value = parts[1].Trim();
                        switch (key)
                        {
                            case "Name":
                                NameText.Text = value;
                                break;
                            case "Surname":
                                SurnameText.Text = value;
                                break;
                            case "Paternal":
                                PaternalText.Text = value;
                                break;
                            case "Country":
                                CountryText.Text = value;
                                break;
                            case "City":
                                CityText.Text = value;
                                break;
                            case "Phone":
                                PhoneText.Text = value;
                                break;
                            case "Birth Date":
                                BirthDatePicker.SelectedDate = DateTime.Parse(value);
                                break;
                            case "Gender":
                                if (value == "Male")
                                    Male.IsChecked = true;
                                else if (value == "Female")
                                    Female.IsChecked = true;
                                break;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("File does not exist.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
